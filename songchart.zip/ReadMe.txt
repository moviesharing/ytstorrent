---------------------------------
Installation instructions are in the 'Documentation' folder, open index.html in your web browser.
---------------------------------

Script Name: SongCharts
Script Demo URI: http://www.armorthemes.com/demo/songcharts/
Description: Top Songs Charts and Music Search Engine Script
Author: ArmorThemes
Author URI: http://www.armorthemes.com/
Version: 1.2